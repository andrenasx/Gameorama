
<?php $__env->startSection('page-title', 'Edit '.$member->username.'\'s profile | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script defer src="<?php echo e(asset('js/edit_profile.js')); ?>"></script>
    <section class="container g-0 mx-auto my-4 col-lg-7">
        <section class="profile-widget bg-white rounded mb-3">
            <form method="POST" action="<?php echo e(route('edit_profile', $member->username)); ?>" enctype="multipart/form-data"
                  id="edit_form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>

                <row class="mb-3">
                    <div class="col-12 justify-content-center">
                        <div class="image-container bg2" id="banner_photo_preview"
                             style="background-image: url(<?php echo e(asset('storage/members/'.$member->banner_image)); ?>); background-size:cover">
                            <img src="<?php echo e(asset('storage/members/'.$member->avatar_image)); ?>" class="avatar"
                                 id="profile_image">
                        </div>
                    </div>
                    <button type="button" class="btn d-flex align-content-center edit_banner_photo camera_icon">
                        <input type="file" hidden id="input_banner_photo" name="banner_photo">
                        <span class="material-icons-outlined" style="font-size: 200%;">camera_alt</span>
                    </button>

                    <div class="">
                        <button type="button" class="btn d-flex align-content-center camera_icon edit_profile_photo">
                            <input type="file" hidden id="input_profile_photo" name="profile_photo">
                            <span class="material-icons-outlined" style="font-size: 200%;">camera_alt</span>
                        </button>
                    </div>
                </row>
                <div class="mt-2 edit_profile_username">
                    <h2 class="h2 fw-bold text-center " id="username"><?php echo e($member->username); ?></h2>
                </div>

                <section class="container w-100 mt-2 form-group p-2">
                    <div class="mb-4">
                        <label for="new-post-title" class="form-label">Display Name</label>
                        <input type="text" class="form-control" id="new-post-title" name="full_name"
                               value="<?php echo e($member->full_name); ?>">
                    </div>
                    <div class="mb-4">
                        <label for="exampleFormControlTextarea1" class="form-label">Biography</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" name="bio" rows="5"
                                  placeholder="Add a bio to your profile!"><?php echo e($member->bio); ?></textarea>
                    </div>
                    <div class="col-12 d-flex justify-content-end">
                        <button type="button" class="btn btn-primary" id="edit_submit_button">Save changes</button>
                    </div>
                </section>
            </form>
        </section>
    </section>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LBAW\lbaw2133\resources\views/pages/edit_profile.blade.php ENDPATH**/ ?>