
<?php $__env->startSection('page-title', 'Home | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script defer src = <?php echo e(asset('js/ajax.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/home.js')); ?>></script>
        <?php if(auth()->guard()->check()): ?>
        <script defer src = <?php echo e(asset('js/voting.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/bookmark.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/report.js')); ?>></script>
        <?php endif; ?>
        
        <?php if(auth()->guard()->guest()): ?>
        <script defer src = <?php echo e(asset('js/login_required.js')); ?>></script>
        <?php endif; ?>

        <script defer src = <?php echo e(asset('js/footer.js')); ?>></script>

    <?php $__env->stopPush(); ?>
    <section class="mainpage-container container my-4 col-lg-8 px-0 mt-md-4">
        <div class="row justify-content-evenly g-0">
            <section class="all-news-cards col-md-8">
                <section class="pill-navigation">
                    <ul class="nav nav-pills mb-1 bg-white rounded" id="pills-tab" role="tablist">
                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item col" role="presentation">
                                <button class="nav-link active w-100" id="pills-feed-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-feed" type="button" role="tab" aria-controls="pills-feed"
                                        aria-selected="true">Feed
                                </button>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item col" role="presentation">
                            <button class="nav-link <?php if(auth()->guard()->guest()): ?> active <?php endif; ?> w-100" id="pills-trending-tab"
                                    data-bs-toggle="pill"
                                    data-bs-target="#pills-trending" type="button" role="tab"
                                    aria-controls="pills-trending"
                                    aria-selected="<?php if(auth()->guard()->check()): ?> false <?php endif; ?> <?php if(auth()->guard()->guest()): ?> true <?php endif; ?>">Trending
                            </button>
                        </li>
                        <li class="nav-item col" role="presentation">
                            <button class="nav-link w-100" id="pills-latest-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-latest" type="button" role="tab" aria-controls="pills-latest"
                                    aria-selected="false">Latest
                            </button>
                        </li>
                    </ul>
                </section>

                <section id="content" class="posts reportable"></section>
                <div id="spinner" class="d-flex justify-content-center mt-5">
                    <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </section>

            <aside class="col-md-3 d-none d-md-block">
                <section id="hall_of_fame" class="row mb-3 p-3 bg-white rounded">
                    <h4 class="aside-title fw-bold px-1">Wall of Fame</h4>
                    <ol class="ms-2 mb-0">
                        <?php $__currentLoopData = $hall_of_fame; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2">
                                <p class="mb-0 blue-hover text-truncate"><a
                                        href="<?php echo e(route('profile', ['username' => $member->username])); ?>"><?php echo e($member->username); ?></a></p>
                                <p class="mb-0 text-truncate small-grey-text"><?php echo e($member->aura); ?> Aura Score</p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </section>

                <section id="popular_topics" class="row mb-3 p-3 bg-white rounded">
                    <h4 class="aside-title fw-bold px-1">Most Popular Topics</h4>
                    <ol class="ms-2 mb-0">
                        <?php $__currentLoopData = $popular_topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poptopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2">
                                <p class="mb-0 blue-hover text-truncate"><a
                                        href="<?php echo e(route('topic', ['name' => $poptopic->name])); ?>"><?php echo e($poptopic->name); ?></a></p>
                                <p class="mb-0 text-truncate small-grey-text"><?php echo e($poptopic->num_followers); ?> Followers</p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </section>
            </aside>
        </div>
        
    </section>
    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('partials.report_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.login_required', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LBAW\lbaw2133\resources\views/pages/home.blade.php ENDPATH**/ ?>