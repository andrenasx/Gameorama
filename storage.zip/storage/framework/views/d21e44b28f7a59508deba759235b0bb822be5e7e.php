<footer class="footer row g-0 d-flex justify-content-between">
    <div class="footer-placeholder g-0 row mt-auto justify-content-between">
    </div>
    <div class="footer-wrapper g-0 row mt-auto justify-content-between">
        <div class="col-12 col-md-4">
            <a class="" href="<?php echo e(route('home')); ?>">Home</a>
            <a class="ms-2" href="<?php echo e(route('about')); ?>">About Us</a>
        </div>

        <span class="color-orange col-12 col-md-8 text-md-end copyright">&copy; Copyright 2021 Gameorama. All rights reserved.</span>
    </div>
</footer>
<?php /**PATH F:\LBAW\lbaw2133\resources\views/partials/footer.blade.php ENDPATH**/ ?>