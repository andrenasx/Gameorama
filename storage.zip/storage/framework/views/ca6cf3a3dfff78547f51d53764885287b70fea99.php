<div class="row g-0 p-3 mb-2 rounded bg-white align-items-center">
    <div class="col-2 col-xl-1 pe-3">
        <img src="<?php echo e(asset('storage/members/'.$member->avatar_image)); ?>" alt="" class="rounded-circle img-fluid img-responsive" style="width:90px;height:auto;">
    </div>
    <div class="col-6 col-xl-9">
        <div class="row g-0">
            <h3 class="h3 color-orange truncate"><a href="<?php echo e(route('profile', ['username' => $member->username])); ?>"><?php echo e($member->username); ?></a></h3>
        </div>
        <div class="row g-0">
            <h5 class="h5 truncate"><?php echo e($member->full_name); ?></h5>
        </div>
    </div>
    <div class="col-4 col-xl-2">
        <div class="row g-0 d-flex justify-content-end">
            <?php if(auth()->guard()->check()): ?>
            <?php if(!$member->isMe(Auth::user()->id)): ?>
                <?php if((Auth::user()->isFollowing($member->id)) != null): ?>
                    <button type="button" data-id = <?php echo e($member->username); ?>

                        class="following-button btn btn-outline-primary col-12 mb-1 member-follow-button"> 
                    </button>
                <?php else: ?>
                    <button type="button" data-id = <?php echo e($member->username); ?>

                        class="follow-button btn btn-outline-primary col-12 mb-1 member-follow-button">
                    </button>
                <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="row g-0">
            <p class="m-0 d-flex justify-content-end" id="member_followers" data-id=<?php echo e($member->username); ?>><?php echo e($member->followers->count()); ?> Followers</p>
        </div>
    </div>
</div>
<?php /**PATH F:\LBAW\lbaw2133\resources\views/partials/membercard.blade.php ENDPATH**/ ?>