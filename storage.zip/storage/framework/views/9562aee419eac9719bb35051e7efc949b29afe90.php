<div class="news-card mb-3 p-4 rounded bg-white" data-id=<?php echo e($post->id); ?>>
    <header class="row news-card-header">
        
        <div class="col">
            <h6 class="post-topics">Topics:
                <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href=<?php echo e(route('topic', ['name' => $topic->name])); ?>><?php echo e($topic->name); ?></a>;
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="">
                <small class="post-user">Posted by 
                    <a href="<?php echo e(route('profile', $post->owner->username)); ?>"><?php echo e($post->owner->username); ?></a></small>
                <small><?php echo e($post->get_time()); ?></small>
            </div>
            <h4 class="post-title-smaller mb-3">
                <a href=<?php echo e(route('post', ['id_post' => $post->id])); ?> class="black-a"><?php echo e($post->title); ?></a>
            </h4>
        </div>
    </header>
    <div class="news-card-body">
        <a href=<?php echo e(route('post', ['id_post' => $post->id])); ?> class="black-a">
            <?php if($post->images->count () > 0): ?>
                <img class="rounded img-fluid img-responsive mx-auto my-3 d-block"
                    style="max-height: 650px"
                    src=<?php echo e(asset('storage/posts/'.$post->id.'/'.$post->images[0]['file'])); ?>>
            <?php endif; ?>
            <p class="card-text truncate-multiple"><?php echo e($post->body); ?></p>
        </a>
    </div>
    <div class="row mt-4">
        <hr class="admin_hr">

        <div class="d-flex justify-content-between">
            <h4 class="text-danger"><?php echo e($post->reports->count()); ?> report</h4>
            <div class="col-2 ">
                <div class="col d-flex justify-content-end btn-outline-blue dropdown "
                     id="more-horizontal" role="button" data-bs-toggle="dropdown">
                    <span class="material-icons-round">more_horiz</span>
                </div>
                <ul class="dropdown-menu more-horizontal" aria-labelledby="more-horizontal">
                    <li><a class="dropdown-item btn-outline-blue dismiss"><span
                                class="material-icons-outlined align-middle ">done</span> <span class = "dismiss"> Dismiss</span></a>
                    </li>
                    <li><a class="dropdown-item btn-outline-red delete"><span
                                class="material-icons-outlined align-middle">delete</span> <span class = "delete"> Delete</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div> <!-- /.news-card --><?php /**PATH F:\LBAW\lbaw2133\resources\views/partials/reported_post.blade.php ENDPATH**/ ?>