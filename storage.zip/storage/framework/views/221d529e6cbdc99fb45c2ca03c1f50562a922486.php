<!-- reply -->
<?php $mb=3?>
<?php if($reply->replies->count()!=0): ?>
    <?php $mb=0?>
<?php endif; ?>

<div class = "row g-0 offset-<?php echo e($offset); ?> border rounded mb-<?php echo e($mb); ?>">
    <div class = "d-flex p-4">
        <img src="../assets/avatar2.png" class = "flex-shrink-0 rounded-circle" style="width:60px;height:60px;" alt="">
        <div class = "ms-2 col-lg-11">
            <div class = "row justify-content-between g-0">
                <h4 class="col"><?php echo e($reply->owner->username); ?></h4>
                <small class="col text-end" style = "color: darkgray;"><?php echo e($reply->date_time); ?></small>
            </div>
            
            <p><?php echo e($reply->body); ?></p>

            <div class="row mt-4">
                <div class = "col d-flex justify-content-center post-voting">
                    <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                    <label class = "score d-flex justify-content-center mx-2"><?php echo e($reply->aura); ?></label>
                    <span class="downvote material-icons-round d-flex justify-content-center">south</span>
                </div>
                <div class="col d-flex justify-content-center btn-outline-blue">
                    <span class="material-icons-outlined align-middle me-1">mode_comment</span>
                    <span class="d-none d-md-flex"> Reply</span>
                </div>
                    <?php if(Auth::user()->id===$comment->id_owner): ?>
                        <div class="col d-flex justify-content-center btn-outline-blue dropdown " id="more-horizontal" role="button" data-bs-toggle="dropdown">
                            <span class="material-icons-round">more_horiz</span>
                        </div>
                        <ul class="dropdown-menu more-horizontal" aria-labelledby="more-horizontal" >
                            <li><a class="dropdown-item btn-outline-blue"><span class="material-icons-outlined align-middle">edit</span> <span> Edit</span></a></li>
                            <li><a class="dropdown-item btn-outline-red"><span class="material-icons-outlined align-middle">delete</span> <span> Delete</span></a></li>
                        </ul>
                    <?php else: ?>
                        <div class="col d-flex justify-content-center btn-outline-red" data-bs-toggle="modal" data-bs-target="#reportPost">
                            <span class="material-icons-outlined align-middle me-1">flag</span>
                            <span class="d-none d-md-flex"> Report<span>
                        </div>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $reply->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replyreply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('partials.reply', ['reply' => $replyreply,
    'offset'=>($offset+1)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH F:\LBAW\lbaw2133\resources\views/partials/reply.blade.php ENDPATH**/ ?>