
<?php $__env->startSection('page-title', $member->username.' | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script defer src=<?php echo e(asset('js/ajax.js')); ?>></script>
        <script defer src=<?php echo e(asset('js/profile.js')); ?>></script>
        <script defer src=<?php echo e(asset('js/follow.js')); ?>></script>
        <script defer src=<?php echo e(asset('js/follow_topic.js')); ?>></script>
        <script defer src=<?php echo e(asset('js/voting.js')); ?>></script>
        <script defer src=<?php echo e(asset('js/bookmark.js')); ?>></script>
        <script defer src=<?php echo e(asset('js/report.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/footer.js')); ?>></script>
    <?php $__env->stopPush(); ?>
    <section class="container g-0 mx-auto my-4 col-lg-7">
        <section class="profile-widget bg-white rounded mb-3">
            <div class="row g-0">
                <div class="col-sm-12">
                    <div class="image-container bg2"
                         style="background-image: url(<?php echo e(asset('storage/members/'.$member->banner_image)); ?>); background-size: cover">
                        <img src="<?php echo e(asset('storage/members/'.$member->avatar_image)); ?>" class="avatar">
                    </div>
                    <row class="d-flex justify-content-end col-12 reportable">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if($member->isMe(Auth::user()->id)): ?>
                                <button type="button" class="btn d-flex align-content-center mt-1 me-1">
                                    <span class="btn-outline-blue" style="font-size: 200%;"
                                          onclick="location.href = '/member/<?php echo e($member->username); ?>/edit'">create</span>
                                </button>
                            <?php else: ?>
                                <button type="button" class="btn d-flex align-content-center mt-1 me-1 report-b report-profile " data-id=<?php echo e($member->id); ?>

                                        data-bs-toggle="modal"
                                        data-bs-target="#reportProfile">
                                    <span class="btn-outline-red report-b report-profile" data-id=<?php echo e($member->id); ?> style="font-size: 200%;">flag</span>
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(auth()->guard()->guest()): ?>
                            <button type="button" class="btn d-flex align-content-center mt-1 me-1 report-b report-profile " data-id=<?php echo e($member->id); ?>

                                    data-bs-toggle="modal"
                                    data-bs-target="#reportProfile">
                                <span class="btn-outline-red report-b report-profile" data-id=<?php echo e($member->id); ?> style="font-size: 200%;">flag</span>
                            </button>
                        <?php endif; ?>
                    </row>
                </div>

                <div class="col-sm-12">
                    <div class="details ">
                        <h3><?php echo e($member->full_name); ?></h3>
                        <h4 class="color-orange fst-italic" id="username" data-id = <?php echo e($member->id); ?>><?php echo e($member->username); ?></h4>
                        <p><?php echo e($member->aura); ?> Aura Score</p>
                        <p class="bio mb-4 px-3"><?php echo e($member->bio); ?></p>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(!$member->isMe(Auth::user()->id)): ?>
                                <?php if($member->isFollowed(Auth::user()->id)): ?>
                                    <button type="button" class="following-button btn btn-outline-primary col-4 mb-3 member-follow-button" data-id = <?php echo e($member->username); ?>></button>
                                <?php else: ?>
                                    <button type="button" class="follow-button btn btn-outline-primary col-4 mb-3 member-follow-button" data-id = <?php echo e($member->username); ?>></button>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <section class="follow_stats pb-3">
                    <div class="row g-0 d-flex justify-content-around">
                        <div class="col text-center px-2">
                            <button type="button" class="text-button-profile button-following" data-bs-toggle="modal" data-id = <?php echo e($member->id); ?>

                                    data-bs-target="#modalFollowing"><?php echo e($member->following->count()); ?> Following
                            </button>
                        </div>
                        <div class="col text-center px-2">
                            <button type="button" class="text-button-profile button-followers" data-bs-toggle="modal" data-id = <?php echo e($member->id); ?>

                                    data-bs-target="#modalFollowers"><?php echo e($member->followers->count()); ?> Followers
                            </button>
                        </div>
                        <div class="col text-center px-2">
                            <button type="button" class="text-button-profile button-topics" data-bs-toggle="modal" data-id = <?php echo e($member->id); ?>

                                    data-bs-target="#modalFollowedTopics"><?php echo e($member->topics->count()); ?> Followed Topics
                            </button>
                        </div>
                    </div>
                    <?php echo $__env->make('partials.following', ['following' => $member->following], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('partials.followers', ['followers' => $member->followers], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('partials.followed_topics', ['topics' => $member->topics], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </section>
            </div>
        </section>

        <section class="pill-navigation mb-1">
            <ul class="nav nav-pills mb-1 bg-white rounded" id="pills-tab" role="tablist">
                <li class="nav-item col" role="presentation">
                    <button class="nav-link active w-100" id="pills-posts-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-posts" type="button" role="tab" aria-controls="pills-posts"
                            aria-selected="true">Posts
                    </button>
                </li>
                <li class="nav-item col" role="presentation">
                    <button class="nav-link w-100" id="pills-comments-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-comments" type="button" role="tab" aria-controls="pills-comments"
                            aria-selected="false">Comments
                    </button>
                </li>
                <?php if(auth()->guard()->check()): ?>
                    <?php if($member->isMe(Auth::user()->id)): ?>
                        <li class="nav-item col" role="presentation">
                            <button class="nav-link w-100" id="pills-bookmarked-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-bookmarked" type="button" role="tab"
                                    aria-controls="pills-bookmarked"
                                    aria-selected="false">Bookmarked
                            </button>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </section>
        <section id="content" class="posts comments-section reportable"></section>
        <div id="spinner" class="d-flex justify-content-center mt-5">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.report_comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.report_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.report_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LBAW\lbaw2133\resources\views/pages/profile.blade.php ENDPATH**/ ?>