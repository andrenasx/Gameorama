
<?php $__env->startSection('page-title', $topic->name.' | '); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startPush('scripts'); ?>
    <script defer src = <?php echo e(asset('js/ajax.js')); ?>></script>
    <script defer src = <?php echo e(asset('js/topic.js')); ?>></script>
    <script defer src = <?php echo e(asset('js/voting.js')); ?>></script>
    <script defer src = <?php echo e(asset('js/follow_topic.js')); ?>></script>
    <script defer src = <?php echo e(asset('js/bookmark.js')); ?>></script>
    <script defer src = <?php echo e(asset('js/report.js')); ?>></script>
    <script defer src = <?php echo e(asset('js/footer.js')); ?>></script>
<?php $__env->stopPush(); ?>
<section class="container g-0 mx-auto my-4 col-lg-7 ">
    <header class="p-3 p-lg-5 mb-3 bg-white rounded" style="height:fit-content">
        <h3 class="mb-3 color-orange">Topic Page</h3>
        <section class="row g-0 align-items-center" id="topic-info">
            <div class="col-md-10 col-8">
                <div class="row g-0">
                    <img src="<?php echo e(asset('storage/assets/letters/'.strtoupper(substr($topic->name, 0, 1)).'.png')); ?>" class = "rounded-circle col-2 px-0" alt="" style = "max-width: 100px">
                    <div class="col-10 px-3 my-auto d-flex flex-column">
                        <h3 class="h2 fw-bold" id="topic_name"><?php echo e($topic->name); ?></h3>
                        <h5 id="topic_followers" data_id=<?php echo e($topic->id); ?>><?php echo e($topic->followers->count()); ?> Followers</h5>
                    </div>
                </div>
            </div>

            <div class="col-md-2 col-4 d-flex justify-content-end reportable" data-id=<?php echo e($topic->id); ?> >
                <?php if(auth()->guard()->check()): ?>
                <?php if(($topic->isFollowed(Auth::user()->id)) != null): ?>
                    <button type="button" class="following-button btn btn-outline-primary topic-follow-button" data-id =<?php echo e($topic->id); ?>></button>
                <?php else: ?>
                    <button type="button" class="follow-button btn btn-outline-primary topic-follow-button" data-id =<?php echo e($topic->id); ?>></button>
                <?php endif; ?>
                <button type="button" class="btn d-flex align-content-center mt-1 me-1 report-b report-topic" data-id=<?php echo e($topic->id); ?>

                        data-bs-toggle="modal"
                        data-bs-target="#reportTopic">
                    <span class="btn-outline-red report-b report-topic" style="font-size: 200%;" data-id=<?php echo e($topic->id); ?>>flag</span>
                </button>
                <?php endif; ?>
            </div>
        </section>
    </header>

    <section class="pill-navigation mb-1">
        <ul class="nav nav-pills mb-1 justify-content-space-between bg-white rounded" id="pills-tab"
            role="tablist">
            <li class="nav-item col" role="presentation">
                <button class="nav-link active w-100" id="pills-trending-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-trending" type="button" role="tab" aria-controls="pills-trending"
                    aria-selected="false">Trending</button>
            </li>
            <li class="nav-item col" role="presentation">
                <button class="nav-link w-100" id="pills-latest-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-latest" type="button" role="tab" aria-controls="pills-latest"
                    aria-selected="false">Latest</button>
            </li>
        </ul>
    </section>

    <section id="content" class="posts reportable"></section>
    <div id="spinner" class="d-flex justify-content-center mt-5">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

</section>
<?php echo $__env->make('partials.report_topic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LBAW\lbaw2133\resources\views/pages/topic.blade.php ENDPATH**/ ?>