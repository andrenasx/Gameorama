<div class="news-card mb-3 p-4 rounded bg-white">
    <header class="row g-0 news-card-header">
        <?php if(auth()->guard()->guest()): ?>
        <div class="post-voting col-1 d-flex justify-content-center" >
            <ul class="list-unstyled mb-0">
                <li>
                    <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                </li>
                <li>
                    <span class="score d-flex justify-content-center" id="score"><?php echo e($post->aura); ?></span>
                </li>
                <li>
                    <span
                        class="downvote material-icons-round d-flex justify-content-center">south</span>
                </li>
            </ul>
        </div>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
        <div class="post-voting col-1 d-flex justify-content-center" data-id = <?php echo e($post->id); ?>>
            <ul class="list-unstyled mb-0">
                <li>
                    <?php if(Auth::user()->hasVotedPost($post->id) !== null && Auth::user()->hasVotedPost($post->id)->upvote): ?>
                        <span class="upvote voted material-icons-round d-flex justify-content-center">north</span>
                    <?php else: ?>
                        <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                    <?php endif; ?>
                </li>
                <li>
                    <span class="score d-flex justify-content-center" id="score"><?php echo e($post->aura); ?></span>
                </li>
                <li>
                    <?php if(Auth::user()->hasVotedPost($post->id) !== null && Auth::user()->hasVotedPost($post->id)->upvote == false): ?>
                        <span class="downvote voted material-icons-round d-flex justify-content-center">south</span>
                    <?php else: ?>
                        <span class="downvote material-icons-round d-flex justify-content-center">south</span>
                    <?php endif; ?>

                </li>
            </ul>
        </div>
        <?php endif; ?>

        <div class="post-header col me-2">
            <h6 class="post-topics">Topics:
                <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('topic', ['name' => $topic->name])); ?>"><?php echo e($topic->name); ?></a>;
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h6>
            <div class="d-inline">
                <small class="post-user">Posted by <a href="<?php echo e(route('profile', ['username' => $post->owner->username])); ?>"><?php echo e($post->owner->username); ?></a></small>
                <small><?php echo e($post->get_time()); ?></small>
            </div>
            <h4 class="post-title-smaller">
                <a href="<?php echo e(route('post', ['id_post' => $post->id])); ?>" class="post-title black-a"><?php echo e($post->title); ?></a>
            </h4>
        </div>
    </header>
    <div class="news-card-body">
        <a href="<?php echo e(route('post', ['id_post' => $post->id])); ?>" class="black-a">
            <?php if($post->images->count () > 0): ?>
            <img class="img-fluid img-responsive mx-auto my-3 d-block" style="max-height: 650px"
                src=<?php echo e(asset('storage/posts/'.$post->id.'/'.$post->images[0]['file'])); ?>>
            <?php endif; ?>
            <div class="post-body card-text mt-3 truncate-multiple"><?php echo $post->body; ?></div>
        </a>
    </div>
    <div class="row g-0 mt-4 news-card-options" data-id=<?php echo e($post->id); ?> >
        <a href="<?php echo e(route('post', ['id_post' => $post->id]).'#comments'); ?>" class="col d-flex justify-content-center btn-outline-blue border-end border-2">
            <span class="material-icons-outlined align-middle me-1">mode_comment</span>
            <span class="d-none d-md-flex"> <?php echo e($post->comments->count()); ?></span>
        </a>
        <?php if(auth()->guard()->check()): ?>
            <?php if($post->isBookmarked(Auth::user()->id) === null): ?>
                <div class="col d-flex justify-content-center border-end border-2 bookmark bookmark-btn" data-id = <?php echo e($post->id); ?> >
                    <span class="material-icons-outlined align-middle me-1 bookmark-btn">bookmark_add</span>
                    <span class="d-none d-md-flex bookmark-btn">Bookmark</span>
                </div>
            <?php else: ?>
                <div class="col d-flex justify-content-center border-end border-2 bookmarked bookmarked-btn" data-id = <?php echo e($post->id); ?>>
                    <span class="material-icons-round align-middle me-1 bookmarked-btn">bookmark_added</span>
                    <span class="d-none d-md-flex bookmarked-btn">Bookmarked</span>
                </div>
            <?php endif; ?>

            <?php if($post->owner->isMe(Auth::user()->id)): ?>
                <div class="col d-flex justify-content-center btn-outline-blue dropdown " id="more-horizontal" role="button" data-bs-toggle="dropdown">
                    <span class="material-icons-round">more_horiz</span>
                </div>
                <ul class="dropdown-menu more-horizontal col-1" aria-labelledby="more-horizontal" >
                    <li><a class="dropdown-item btn-outline-blue"><span class="material-icons-outlined align-middle">edit</span> <span> Edit</span></a></li>
                    <li><a class="dropdown-item btn-outline-red"><span class="material-icons-outlined align-middle">delete</span> <span> Delete</span></a></li>
                </ul>
            <?php else: ?>
                <div class="col d-flex justify-content-center btn-outline-red report-b report-post" data-bs-toggle="modal" data-bs-target="#reportPost" data-id= <?php echo e($post->id); ?>>
                    <span class="material-icons-outlined align-middle me-1 report-b report-post" data-id= <?php echo e($post->id); ?>>flag</span>
                    <span class="d-none d-md-flex report-b report-post" data-id= <?php echo e($post->id); ?>> Report</span>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <div class="col d-flex justify-content-center border-end border-2 bookmark bookmark-btn" data-id = <?php echo e($post->id); ?> >
                <span class="material-icons-outlined align-middle me-1 bookmark-btn">bookmark_add</span>
                <span class="d-none d-md-flex bookmark-btn">Bookmark</span>
            </div>
            <div class="col d-flex justify-content-center btn-outline-red report-b report-post" data-bs-toggle="modal" data-bs-target="#reportPost" data-id= <?php echo e($post->id); ?>>
                <span class="material-icons-outlined align-middle me-1 report-b report-post" data-id= <?php echo e($post->id); ?>>flag</span>
                <span class="d-none d-md-flex report-b report-post" data-id= <?php echo e($post->id); ?>> Report</span>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH F:\LBAW\lbaw2133\resources\views/partials/postcard.blade.php ENDPATH**/ ?>