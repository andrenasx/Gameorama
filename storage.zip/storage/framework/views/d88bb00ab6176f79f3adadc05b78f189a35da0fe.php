
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script defer src = <?php echo e(asset('js/ajax.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/search.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/search_follows.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/report.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/footer.js')); ?>></script>
    <?php $__env->stopPush(); ?>
<section class="container g-0 mx-auto my-4 col-lg-7 ">
    <header class="p-4 p-lg-5 mb-3 bg-white rounded" style="height:fit-content">
        <h3 class="mb-3 color-orange">Results for</h3>
        <h2 id="query" class="fw-bold"><?php echo e($query); ?></h2>
    </header>

    <section class="pill-navigation mb-1">
        <ul class="nav nav-pills mb-1 justify-content-space-between bg-white rounded" id="pills-tab"
            role="tablist">
            <li class="nav-item col" role="presentation">
                <button class="nav-link active w-100" id="pills-posts-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-posts" type="button" role="tab" aria-controls="pills-posts"
                    aria-selected="false">Posts</button>
            </li>
            <li class="nav-item col" role="presentation">
                <button class="nav-link w-100" id="pills-topics-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-topics" type="button" role="tab" aria-controls="pills-topics"
                    aria-selected="false">Topics</button>
            </li>
            <li class="nav-item col" role="presentation">
                <button class="nav-link w-100" id="pills-members-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-members" type="button" role="tab" aria-controls="pills-members"
                    aria-selected="false">Members</button>
            </li>
        </ul>
    </section>
    <section id="content" class="posts reportable"></section>
    <div id="spinner" class="d-flex justify-content-center mt-5">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    
</section>
<?php echo $__env->make('partials.report_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LBAW\lbaw2133\resources\views/pages/search.blade.php ENDPATH**/ ?>