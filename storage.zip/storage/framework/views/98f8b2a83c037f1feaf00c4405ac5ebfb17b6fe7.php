
<?php $__env->startSection('page-title', $post->title.' | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script defer src = <?php echo e(asset("js/ajax.js")); ?>></script>
        <script defer src = <?php echo e(asset("js/voting.js")); ?>></script>
        <script defer src = <?php echo e(asset("js/comments.js")); ?>></script>
        <script defer src = <?php echo e(asset('js/bookmark.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/report.js')); ?>></script>
        <script defer src = <?php echo e(asset('js/footer.js')); ?>></script>
    <?php $__env->stopPush(); ?>
    <section class="container bg-white rounded g-0 mx-auto my-4 col-lg-7"  data-id = <?php echo e($post->id); ?> >
        <section class="news-card mb-3 p-4 posts">
            <header class="row news-card-header">
                <?php if(auth()->guard()->guest()): ?>
                <div class="post-voting col-1 d-flex justify-content-center" data-id = <?php echo e($post->id); ?>>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                        </li>
                        <li>
                            <span class="score d-flex justify-content-center" id="score"><?php echo e($post->aura); ?></span>
                        </li>
                        <li>
                            <span
                                class="downvote material-icons-round d-flex justify-content-center">south</span>
                        </li>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                <div class="post-voting col-1 d-flex justify-content-center" data-id = <?php echo e($post->id); ?>>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <?php if(Auth::user()->hasVotedPost($post->id) != null && Auth::user()->hasVotedPost($post->id)->upvote == 1): ?>
                                <span class="upvote voted material-icons-round d-flex justify-content-center">north</span>
                            <?php else: ?>
                                <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                            <?php endif; ?>
                        </li>
                        <li>
                            <span class="score d-flex justify-content-center" id="score"><?php echo e($post->aura); ?></span>
                        </li>
                        <li>
                            <?php if(Auth::user()->hasVotedPost($post->id) !== null && Auth::user()->hasVotedPost($post->id)->upvote == false): ?>
                                <span class="downvote voted material-icons-round d-flex justify-content-center">south</span>
                            <?php else: ?>
                                <span class="downvote material-icons-round d-flex justify-content-center">south</span>
                            <?php endif; ?>

                        </li>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="post-header col me-2">
                    <h5 class="post-topics">Topics:
                        <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('topic', ['name' => $topic->name])); ?>"><?php echo e($topic->name); ?></a>;
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </h5>
                    <div class="d-inline">
                        <small class="post-user">Posted by <a
                                href="<?php echo e(route('profile', $post->owner->username)); ?>"><?php echo e($post->owner->username); ?></a></small>
                        <small><?php echo e($post->get_time()); ?></small>
                    </div>
                    <h1 class="post-title"><?php echo e($post->title); ?></h1>
                </div>
            </header>
            <div class="news-card-body " >
                <?php if($post->images->count() > 0): ?>
                    <div id="myCarousel" class="offset-lg-1 mb-5 col-lg-10 carousel slide" data-bs-ride="carousel">
                        <?php if($post->images->count() > 1): ?>
                            <div class="carousel-indicators">
                                <?php for($index = 0; $index < $post->images->count(); $index++): ?>
                                    <?php if($index == 0): ?>
                                        <button type="button" data-bs-target="#carouselExampleIndicators"
                                                data-bs-slide-to="<?php echo e($index); ?>" class="active" aria-current="true"
                                                aria-label="Slide <?php echo e($index); ?>"></button>
                                    <?php else: ?>
                                        <button type="button" data-bs-target="#carouselExampleIndicators"
                                                data-bs-slide-to="<?php echo e($index); ?>" aria-label="Slide <?php echo e($index); ?>"></button>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                        <?php endif; ?>
                        <div class="carousel-inner">
                            <?php for($index = 0; $index < $post->images->count(); $index++): ?>
                                <?php if($index == 0): ?>
                                <div class="carousel-item active">
                                <?php else: ?>
                                <div class="carousel-item">
                                <?php endif; ?>
                                    <img src="<?php echo e(asset('storage/posts/'.$post->id.'/'.$post->images[$index]['file'])); ?>" alt="Post Image" class="d-block w-100">
                                </div>
                            <?php endfor; ?>
                        </div>
                        <?php if($post->images->count() > 1): ?>
                            <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel"
                                    data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#myCarousel"
                                    data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                        <div class="card-text mt-3 px-lg-4"><?php echo $post->body; ?></div>
                    </div>
                    <div class="row mt-4 news-card-options  reportable" >
                        <a href="#comments" class="col d-flex justify-content-center btn-outline-blue border-end border-2">
                            <span class="material-icons-outlined align-middle me-1">mode_comment</span>
                            <span class="d-none d-md-flex"> <?php echo e($post->comments->count()); ?></span>
                        </a>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if($post->isBookmarked(Auth::user()->id) === null): ?>
                                <div class="col d-flex justify-content-center border-end border-2 bookmark bookmark-btn" data-id = <?php echo e($post->id); ?>>
                                    <span class="material-icons-outlined align-middle me-1 bookmark-btn">bookmark_add</span>
                                    <span class="d-none d-md-flex bookmark-btn">Bookmark</span>
                                </div>
                            <?php else: ?>
                                <div class="col d-flex justify-content-center bookmarked border-end border-2 bookmarked bookmarked-btn" data-id = <?php echo e($post->id); ?>>
                                    <span class="material-icons-round align-middle me-1 bookmarked-btn">bookmark_remove</span>
                                    <span class="d-none d-md-flex bookmarked-btn">Bookmarked</span>
                                </div>
                            <?php endif; ?>

                            <?php if($post->owner->isMe(Auth::user()->id)): ?>
                                <div class="col d-flex justify-content-center btn-outline-blue dropdown " id="more-horizontal" role="button" data-bs-toggle="dropdown">
                                    <span class="material-icons-round">more_horiz</span>
                                </div>
                                <ul class="dropdown-menu more-horizontal col-1" aria-labelledby="more-horizontal" >
                                    <li><a class="dropdown-item btn-outline-blue"><span class="material-icons-outlined align-middle">edit</span> <span> Edit</span></a></li>
                                    <li><a class="dropdown-item btn-outline-red"><span class="material-icons-outlined align-middle">delete</span> <span> Delete</span></a></li>
                                </ul>
                            <?php else: ?>
                                <div class="col d-flex justify-content-center btn-outline-red report-b report-post" data-bs-toggle="modal" data-bs-target="#reportPost" data-id= <?php echo e($post->id); ?>>
                                    <span class="material-icons-outlined align-middle me-1 report-b report-post" data-id= <?php echo e($post->id); ?>>flag</span>
                                    <span class="d-none d-md-flex report-b report-post" data-id= <?php echo e($post->id); ?>> Report</span>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if(auth()->guard()->guest()): ?>
                            <div class="col d-flex justify-content-center border-end border-2 bookmark bookmark-btn" data-id = <?php echo e($post->id); ?>>
                                <span class="material-icons-outlined align-middle me-1 bookmark-btn">bookmark_add</span>
                                <span class="d-none d-md-flex bookmark-btn">Bookmark</span>
                            </div>
                            <div class="col d-flex justify-content-center btn-outline-red report-b report-post" data-bs-toggle="modal" data-id=<?php echo e($post->id); ?>

                                data-bs-target="#reportPost">
                                <span class="material-icons-outlined align-middle me-1 report-b report-post" data-id=<?php echo e($post->id); ?>>flag</span>
                                <span class="d-none d-md-flex report-b report-post" data-id=<?php echo e($post->id); ?>> Report</span>
                            </div>
                        <?php endif; ?>

                        <?php echo $__env->make('partials.report_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
        </section>


        <section id="comments" class="comments p-2 px-sm-4 mt-3 ">
            <section class="row g-0 mb-4" data-id="<?php echo e($post->id); ?>" id="new-comment-section">
                <div class="md-form amber-textarea active-amber-textarea px-0 ">
                    <textarea class="form-control" id = "comment_content" name="comment" rows="4" placeholder="Leave a comment"></textarea>
                    <button type="button" id = "make_comment_button" class="btn btn-primary mt-2 float-end">Add Comment</button>
                </div>
            </section>

            <section class = "comments-section reportable">
                <?php $__currentLoopData = $post->parentComments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.comment', ['comment' => $comment, 'offset' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </section>


    </section>
    <?php echo $__env->make('partials.report_comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LBAW\lbaw2133\resources\views/pages/post.blade.php ENDPATH**/ ?>