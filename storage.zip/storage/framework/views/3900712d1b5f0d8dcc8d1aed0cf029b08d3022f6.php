<div class="row p-3 g-0 mb-3 rounded border bg-white profile-comment" data-id = <?php echo e($comment->id); ?>>
    <header class="d-flex justify-content-between">
        <h5 class="font-weight-bold">on "<a href="/post/<?php echo e($comment->post->id); ?>"><?php echo e($comment->post->title); ?></a>"</h5>
        <small style="color: darkgray;"><?php echo e($comment->get_time()); ?></small>
    </header>

    <textarea hidden autofocus class = "form-control edit-textarea mb-4" rows="3" ><?php echo $comment->body; ?></textarea>
    <p class="comment_body"><?php echo $comment->body; ?></p>
    <div class = "d-flex justify-content-end edit_button_div post" data-id = <?php echo e($comment->id); ?>>
        <button type = "button" hidden class="col-4 col-md-3 btn btn-primary edit_button me-3 float-end">Edit</button>
        <button type = "button" hidden class="col-4 col-md-3 btn btn-danger cancel_button float-end">Cancel</button>
    </div>
    <div class="d-flex justify-content-between mt-2">
        <div class="col-4 col-sm-2 d-flex justify-content-center comment-voting" data-id = <?php echo e($comment->id); ?>>
            <?php if(auth()->guard()->guest()): ?>
                <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                <label class="score d-flex justify-content-center mx-2"><?php echo e($comment->aura); ?></label>
                <span class="downvote material-icons-round d-flex justify-content-center">south</span>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->hasVotedComment($comment->id) != null && Auth::user()->hasVotedComment($comment->id)->upvote == 1): ?>
                        <span class="upvote voted material-icons-round d-flex justify-content-center">north</span>
                    <?php else: ?>    
                        <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                    <?php endif; ?>
                <span class="score d-flex justify-content-center" id="score"><?php echo e($comment->aura); ?></span>
                    <?php if(Auth::user()->hasVotedComment($comment->id) !== null && Auth::user()->hasVotedComment($comment->id)->upvote == 0): ?>
                        <span class="downvote voted material-icons-round d-flex justify-content-center">south</span>
                    <?php else: ?>
                        <span class="downvote material-icons-round d-flex justify-content-center">south</span>
                    <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if(auth()->guard()->check()): ?>
            <?php if($comment->owner->isMe(Auth::user()->id)): ?>
                <div class="d-flex btn-outline-blue dropdown " id="more-horizontal" role="button" data-bs-toggle="dropdown">
                    <span class="material-icons-round">more_horiz</span>
                </div>
                <ul class="dropdown-menu col-1 more-horizontal comment_options profile" aria-labelledby="more-horizontal" data-id = <?php echo e($comment->id); ?>>
                    <li><a class="dropdown-item btn-outline-blue edit-comment"><span class="material-icons-outlined align-middle edit-comment">edit</span> <span class = "edit-comment"> Edit</span></a></li>
                    <li><a class="dropdown-item btn-outline-red delete-comment"><span class="material-icons-outlined align-middle delete-comment">delete</span> <span class = "delete-comment"> Delete</span></a></li>
                </ul>
            <?php else: ?>
                <div class="d-flex btn-outline-red report-b report-comment" data-id = <?php echo e($comment->id); ?> data-bs-toggle="modal" data-bs-target="#reportComment">
                    <span class="material-icons-outlined align-middle me-1 report-b report-comment" data-id = <?php echo e($comment->id); ?>>flag</span>
                    <span class="d-none d-md-flex report-b report-comment" data-id = <?php echo e($comment->id); ?>> Report</span>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <div class="d-flex btn-outline-red report-b report-comment" data-id = <?php echo e($comment->id); ?> data-bs-toggle="modal" data-bs-target="#reportComment">
                <span class="material-icons-outlined align-middle me-1 report-b report-comment" data-id = <?php echo e($comment->id); ?>>flag</span>
                <span class="d-none d-md-flex report-b report-comment" data-id = <?php echo e($comment->id); ?>> Report</span>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH F:\LBAW\lbaw2133\resources\views/partials/commentcard.blade.php ENDPATH**/ ?>