<?php $mb=2?>
<?php if($comment->replies->count()!=0): ?>
    <?php $mb=0?>
<?php endif; ?>
<?php $mt=3?>
<?php if($offset!=0): ?>
    <?php $mt=100?>
<?php endif; ?>
<?php if($offset>5): ?>
    <?php $offset=5?>
<?php endif; ?>

<div class = "post-comment" data-id = <?php echo e($comment->id); ?>>
    <div class = "row g-0 offset-<?php echo e($offset); ?> border-start border-bottom border-3 mb-<?php echo e($mb); ?> mt-<?php echo e($mt); ?> comment-<?php echo e($comment->id); ?>" >
        <div class = "d-flex px-3 py-3 ">
            <img class = "flex-shrink-0 rounded-circle" style="width:60px;height:60px;" src="<?php echo e(asset('storage/members/'.$comment->owner->avatar_image)); ?>" alt="">
            <div class = "ms-2 col-10 col-lg-11 comment_box">
                <div class = "row justify-content-between g-0">
    
                    <h5 class="col color-orange"><a href="/member/<?php echo e($comment->owner->username); ?>"><?php echo e($comment->owner->username); ?></a></h5>
    
                    <small class="col text-end" style = "color: darkgray;"><?php echo e($comment->get_time()); ?></small>
                </div>
                <textarea hidden autofocus class = "form-control edit-textarea mb-4" rows="3" ><?php echo $comment->body; ?></textarea>
                <p class="mb-2 comment_body"><?php echo $comment->body; ?></p>
                <div class = "d-flex justify-content-end mb-3 edit_button_div post" data-id = <?php echo e($comment->id); ?>>
                    <button type = "button" hidden class="col-4 col-md-3 btn btn-primary edit_button me-3 float-end">Edit</button>
                    <button type = "button" hidden class="col-4 col-md-3 btn btn-danger cancel_button float-end">Cancel</button>
                </div>
                <div class="row comment_options" data-id = <?php echo e($comment->id); ?>>
    
                    <div class = "col-4 d-flex justify-content-center comment-voting border-end border-2" data-id = <?php echo e($comment->id); ?>>
                        <?php if(auth()->guard()->guest()): ?>
                            <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                            <label class = "score d-flex justify-content-center mx-2"><?php echo e($comment->aura); ?></label>
                            <span class="downvote material-icons-round d-flex justify-content-center">south</span>
                        <?php endif; ?>
    
                        <?php if(auth()->guard()->check()): ?>
                            <?php if((Auth::user()->hasVotedComment($comment->id) != null) && (Auth::user()->hasVotedComment($comment->id)->upvote == 1)): ?>
                                <span class="upvote voted material-icons-round d-flex justify-content-center">north</span>
                            <?php else: ?>    
                                <span class="upvote material-icons-round d-flex justify-content-center">north</span>
                            <?php endif; ?>
                            <span class="score d-flex justify-content-center" id="score"> <?php echo e($comment->aura); ?> </span>
    
                            <?php if(Auth::user()->hasVotedComment($comment->id) != null && Auth::user()->hasVotedComment($comment->id)->upvote == 0): ?>
                                <span class="downvote voted material-icons-round d-flex justify-content-center">south</span>
                            <?php else: ?>
                                <span class="downvote material-icons-round d-flex justify-content-center">south</span>
                            <?php endif; ?>                       
                        <?php endif; ?>
    
                    </div>
                    <div class="col-4 d-flex justify-content-center btn-outline-blue border-end border-2 reply-comment-button comment_options" data-id = <?php echo e($comment->id); ?> data-bs-toggle="collapse" href="#comment_<?php echo e($comment->id); ?>" role = "button" aria-controls = "comment_<?php echo e($comment->id); ?>">
                        <span class="material-icons-outlined align-middle me-1 reply-comment-button" data-id = <?php echo e($comment->id); ?>>mode_comment</span>
                        <span class="d-none d-md-flex reply-comment-button" data-id = <?php echo e($comment->id); ?>  > Reply</span>
                    </div>
                    <?php if(Auth::check() && Auth::user()->id===$comment->id_owner): ?>
                        <div class="col d-flex justify-content-center btn-outline-blue dropdown" id="more-horizontal" role="button" data-bs-toggle="dropdown">
                            <span class="material-icons-round">more_horiz</span>
                        </div>
                        
                        <ul class="dropdown-menu col-1 more-horizontal comment_options post" aria-labelledby="more-horizontal" data-id = <?php echo e($comment->id); ?>>
                            <li><a class="dropdown-item btn-outline-blue edit-comment"><span class="material-icons-outlined align-middle edit-comment">edit</span> <span class = "edit-comment"> Edit</span></a></li>
                            <li><a class="dropdown-item btn-outline-red delete-comment"><span class="material-icons-outlined align-middle delete-comment">delete</span> <span class = "delete-comment"> Delete</span></a></li>
                        </ul>
                        
                    <?php else: ?>
                        <div class="col-4 d-flex justify-content-center btn-outline-red report-b report-comment" data-bs-toggle="modal" data-bs-target="#reportComment" data-id=<?php echo e($comment->id); ?>>
                            <span class="material-icons-outlined align-middle me-1 report-b report-comment" data-id=<?php echo e($comment->id); ?>>flag</span>
                            <span class="d-none d-md-flex report-b report-comment" data-id=<?php echo e($comment->id); ?>> Report</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <section class = "reply-comment col-10 offset-1 mb-2 collapse" id = "comment_<?php echo e($comment->id); ?>" data-id = "<?php echo e($comment->id); ?>" >
            
            <textarea type="text" class="form-control inputOldPass content" data-id = <?php echo e($comment->id); ?> placeholder="Leave your reply" rows="4" placeholder="Reply"></textarea>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary cancel_reply" data-bs-toggle="collapse" aria-expanded="false" data-bs-target="#comment_<?php echo e($comment->id); ?>">Cancel</button>
            <button class="btn btn-primary reply-button" >Reply</button>
        </div>
    </section>
    <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('partials.comment', ['comment' => $reply, 'offset' => $offset + 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    <div class="modal fade reply-fade" id="staticReplyModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Reply to Comment</h5>
                    <button type="button" data-bs-dismiss="modal" id="close-window-button" aria-label="Close"><span
                            class="material-icons-round">close</span></button>
                </div>
                <form class="reply-form" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-floating" data-id = <?php echo e($comment->post->id); ?>>
                            <textarea type="text" class="form-control inputOldPass" data-id = <?php echo e($comment->id); ?> placeholder=" " rows="5" placeholder="Reply"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary dismiss-modal" data-bs-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary reply-button" data-id = "<?php echo e($comment->id); ?>">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>
<?php /**PATH F:\LBAW\lbaw2133\resources\views/partials/comment.blade.php ENDPATH**/ ?>